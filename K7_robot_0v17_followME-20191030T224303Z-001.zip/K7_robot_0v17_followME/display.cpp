#include <Adafruit_GFX.h>
#include "Adafruit_ST7735.h"
#include "display.h"

extern Adafruit_ST7735 tft;


// Globals for display management.
uint32_t previous_blink_ms = 0;
uint32_t blink_again = 1500; // Time between blinks.
uint32_t blink_length = 300; // Time for blink.
face_t face_state = SMILE;

// Change/update the face.
void display_update_face(face_t new_face_state, bool force) {
  if (!force && face_state == new_face_state) {
    return;
  }

  face_state = new_face_state;

  switch (face_state) {
    case SMILE               : display_smiling_face(); break;
    case BIG_SMILE           : display_bigger_smile(); break;
    case HEART_EYES          : display_heart_eyes(); break;
    case THE_STARE           : display_the_stare(); break;
    case MEH                 : display_meh(); break;
    case SURPRISED           : display_surprised(); break;
    case SURPRISED_EYES_OPEN : display_surprised_eyes_open(); break;
    case ANGRY               : display_angry(); break;
    case SAD                 : display_sad(); break;
    case BLINK               : display_eyeblink(); break;
  }
}

// Get the current face.
face_t display_get_face(void) {
  return face_state;
}

// Manage the face and eyes blinking. Needs to be called from loop().
void display_manage_face(void) {
  // Manage the time of the blink.
  if (face_state == SMILE) {
    if (millis() - previous_blink_ms >= blink_again) {
      // Time to blink again!
      display_update_face(BLINK);
      previous_blink_ms = millis();
    }
  }
  else if (face_state == BLINK) {
    if (millis() - previous_blink_ms >= blink_length) {
      // Time to smile.
      display_update_face(SMILE);
      previous_blink_ms = millis();
    }
  }
}

/* Initialize the display. */
void display_init(void) {
  // Use this initializer if using a 1.8" TFT screen:
  tft.initR(INITR_BLACKTAB);      // Init ST7735S chip, black tab
  tft.setRotation(3);
  tft.fillScreen(ST77XX_BLACK);
  // backLight (true);


  // tft.drawBitmap(25, 0, ocsbBitmap, 95, 128, ST77XX_WHITE);
  // tft.drawBitmap(5, 0, tdbitmap, 143, 128, ST77XX_GREEN);
  // tft.drawBitmap(0, 40, cubitmap, 160, 40, ST77XX_WHITE);

  delay (5000);
  //display.begin(contrast);
  //display.setRotation(2);  // Rotate the screen so text is upright.
  // display.clearDisplayRAM();
  tft.fillScreen(ST77XX_BLACK);
}

/* Quick way to print a line of text. */
void display_text(const char *text, uint8_t x, uint8_t y, uint8_t size) {
  // void display_text(const char *text, uint8_t x, uint8_t y, uint8_t size, uint16_t color) {

  //  tft.setTextWrap(true);

  tft.setTextSize(size);
  tft.setCursor(x, y);
  tft.setTextColor(ST77XX_WHITE);
  tft.print(text);

}

extern volatile long CurrentPositionRight;//  = 0;
extern volatile long CurrentPositionLeft;

void putPositions (void) {
  tft.fillRect(0, 110, 160, 128, ST77XX_BLACK);
  
  tft.setTextSize(2);
  tft.setTextColor(ST77XX_WHITE);
  
  tft.setCursor(0, 110);
  tft.print(CurrentPositionRight);
  tft.setCursor(80, 110);
  tft.print(CurrentPositionLeft);
  
}

/* Quick way to print an int. */
void display_int(int integer, uint8_t x, uint8_t y, uint8_t size) {

  tft.setTextSize(size);
  tft.setCursor(x, y);
  tft.setTextColor(ST77XX_WHITE);
  tft.print(integer);

}

/* Default expression: two filled circle eyes and a smiling mouth. */
void display_smiling_face(void) {
  //tft.fillScreen(ST77XX_BLACK);
  // tft.setRotation(3);

  //tft.fillCircle(24, 30, 8, ST77XX_WHITE);
  //tft.fillCircle(60, 30, 8, ST77XX_WHITE);


  tft.fillCircle(40, 40, 20, ST77XX_WHITE);
  tft.fillCircle(100, 40, 20, ST77XX_WHITE);
  tft.fillCircle(40, 45, 10, ST77XX_BLUE);
  tft.fillCircle(100, 45, 10, ST77XX_BLUE);


  tft.setCursor(70, 70);
  tft.setTextSize(4);
  tft.setRotation(0);
  tft.print(")");
  tft.setRotation(3);
}

void display_heart_eyes(void) {
  tft.fillScreen(ST77XX_BLACK);
  tft.setRotation(3);

  //left eye
  tft.fillCircle(21, 10, 5, ST77XX_WHITE);
  tft.fillCircle(29, 10, 5, ST77XX_WHITE);
  tft.fillTriangle(15, 10, 35, 10, 25, 19, ST77XX_WHITE);

  //right eye
  tft.fillCircle(51, 10, 5, ST77XX_WHITE);
  tft.fillCircle(59, 10, 5, ST77XX_WHITE);
  tft.fillTriangle(45, 10, 65, 10, 55, 19, ST77XX_WHITE);

  //mouth
  tft.fillCircle(40, 30, 5, ST77XX_WHITE);
  tft.fillCircle(40, 28, 5, ST77XX_BLACK);

}

void display_the_stare(void) {
  tft.fillScreen(ST77XX_BLACK);
  tft.setRotation(2);


  //left eye
  tft.fillRect(15, 7, 20, 2, ST77XX_WHITE);
  tft.fillCircle(21, 10, 2, ST77XX_WHITE);
  tft.fillRect(15, 12, 20, 2, ST77XX_WHITE);

  //right eye
  tft.fillRect(45, 7, 20, 2, ST77XX_WHITE);
  tft.fillCircle(51, 10, 2, ST77XX_WHITE);
  tft.fillRect(45, 12, 20, 2, ST77XX_WHITE);

  //mouth
  tft.fillCircle(40, 33, 10, ST77XX_WHITE);
  tft.fillCircle(40, 35, 10, ST77XX_BLACK);


}

void display_bigger_smile(void) {
  tft.fillScreen(ST77XX_BLACK);
  tft.setRotation(0);

  //left eye
  tft.fillCircle(60, 30, 12, ST77XX_WHITE);

  //right eye
  tft.fillCircle(24, 30, 12, ST77XX_WHITE);

  //mouth
  tft.fillCircle(40, 10, 5, ST77XX_WHITE);
  tft.fillCircle(40, 15, 5, ST77XX_BLACK);
  //display.display();
}

void display_meh(void) {
  tft.fillScreen(ST77XX_BLACK);
  tft.setRotation(0);


  //left eye
  tft.fillCircle(60, 30, 12, ST77XX_WHITE);

  //right eye
  tft.fillCircle(24, 30, 12, ST77XX_WHITE);

  //mouth
  tft.fillRect(20, 5, 35, 5, ST77XX_WHITE);


}

void display_surprised(void) {
  tft.fillScreen(ST77XX_BLACK);
  tft.setRotation(0);

  //left eye
  tft.fillCircle(60, 30, 12, ST77XX_WHITE);

  //right eye
  tft.fillCircle(24, 30, 12, ST77XX_WHITE);

  //mouth
  tft.fillCircle(40, 10, 5, ST77XX_WHITE);



}

void display_surprised_eyes_open(void) {
  tft.fillScreen(ST77XX_BLACK);
  tft.setRotation(0);

  //left eye
  tft.fillCircle(60, 30, 12, ST77XX_WHITE);
  tft.fillCircle(60, 30, 8, ST77XX_BLACK);

  //right eye
  tft.fillCircle(24, 30, 12, ST77XX_WHITE);
  tft.fillCircle(24, 30, 8, ST77XX_BLACK);

  //mouth
  tft.fillCircle(40, 10, 5, ST77XX_WHITE);


}

void display_angry(void) {
  tft.fillScreen(ST77XX_BLACK);
  tft.setRotation(2);

  //left eyebrow
  tft.drawLine(20, 2, 30, 7, ST77XX_WHITE);
  tft.drawLine(21, 2, 31, 7, ST77XX_WHITE);
  tft.drawLine(22, 2, 32, 7, ST77XX_WHITE);

  //left eye
  tft.fillCircle(21, 10, 5, ST77XX_WHITE);


  //right eyebrow
  tft.drawLine(52, 2, 37, 8, ST77XX_WHITE);
  tft.drawLine(53, 2, 38, 8, ST77XX_WHITE);
  tft.drawLine(54, 2, 39, 8, ST77XX_WHITE);

  //right eye
  tft.fillCircle(51, 10, 5, ST77XX_WHITE);

  //mouth
  tft.fillCircle(40, 33, 10, ST77XX_WHITE);
  tft.fillCircle(40, 35, 10, ST77XX_BLACK);


}

void display_sad(void) {
  tft.fillScreen(ST77XX_BLACK);
  tft.setRotation(2);

  //left eyebrow
  tft.drawLine(18, 2, 8, 10, ST77XX_WHITE);
  tft.drawLine(19, 2, 9, 10, ST77XX_WHITE);
  tft.drawLine(20, 2, 10, 10, ST77XX_WHITE);

  //left eye
  tft.fillCircle(21, 10, 5, ST77XX_WHITE);

  //right eyebrow
  tft.drawLine(46, 1, 60, 6, ST77XX_WHITE);
  tft.drawLine(47, 1, 61, 6, ST77XX_WHITE);
  tft.drawLine(48, 1, 62, 6, ST77XX_WHITE);

  //right eye
  tft.fillCircle(51, 10, 5, ST77XX_WHITE);

  //tear
  tft.drawLine(52, 22, 54, 18, ST77XX_WHITE);
  tft.drawLine(56, 22, 54, 17, ST77XX_WHITE);
  tft.fillCircle(54, 22, 2, ST77XX_WHITE);

  //mouth
  tft.fillCircle(40, 33, 10, ST77XX_WHITE);
  tft.fillCircle(40, 35, 10, ST77XX_BLACK);


}

/* Eye blinks for 500 ms and then back to default expression. */
void display_eyeblink(void) {
  // tft.setRotation(3);
  //tft.fillScreen(ST77XX_BLACK);


  tft.fillCircle(40, 40, 20, ST77XX_WHITE);
  tft.fillCircle(100, 40, 20, ST77XX_WHITE);
  //tft.fillCircle(40, 45, 10, ST77XX_BLUE);
  // tft.fillCircle(100, 45, 10, ST77XX_BLUE);

  tft.drawLine(33, 45, 47, 43, ST77XX_BLUE);
  tft.drawLine(33, 46, 47, 44, ST77XX_BLUE);

  tft.drawLine(93, 43, 107, 45, ST77XX_BLUE);
  tft.drawLine(93, 44, 107, 46, ST77XX_BLUE);

  tft.setCursor(70, 70);
  tft.setTextSize(4);
  tft.setRotation(0);
  tft.print(")");
  tft.setRotation(3);




}
