#include  "Arduino.h"
#include  "pins.h"
#include <IRremote.h>
#include "prototypes.h"

IRrecv irrecv(IRpin);
decode_results results;

void remoteSetup (void) {

  irrecv.enableIRIn(); // Start the receiver

}


uint32_t remoteCheck (void) {
  uint32_t remoteSignal = 0;

  if (irrecv.decode(&results)) {
    // Serial.println(results.value, HEX);
    remoteSignal = results.value;
    irrecv.resume(); // Receive the next value
  }
  return remoteSignal;

}


const uint32_t forwardCode  = 16718055;
const uint32_t reverseCode  = 16730805;
const uint32_t leftCode     = 16716015;
const uint32_t rightCode    = 16734885;
const uint32_t stopCode     = 16726215;

void remoteCheckMove (void) {

  uint32_t remoteSignal = 0;
  if (irrecv.decode(&results)) {
    // Serial.println(results.value, HEX);
    remoteSignal = results.value;
    irrecv.resume(); // Receive the next value
  }

  switch (remoteSignal) {

    case forwardCode:
      moveRobot (1, 40, 1); //(uint8_t robotSpeed, uint32_t robotSteps,  int8_t robotDirection)
      break;
      
    case reverseCode:
      moveRobot (1, 40, -1); //(uint8_t robotSpeed, uint32_t robotSteps,  int8_t robotDirection)
      break;


      
  }



  // moveRobot (uint8_t robotSpeed, uint32_t robotSteps,  int8_t robotDirection)
  // turnRobot (uint8_t robotSpeed, int16_t robotSteps, int8_t robotDirection )

}
