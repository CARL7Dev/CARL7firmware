// #include "prototypes.h"


#include  "pins.h"
#include "Arduino.h"
void moveRobot (uint8_t , uint32_t ,  int8_t );
void led (uint8_t color, bool state);












uint32_t distanceMeasure (void)
{
  uint32_t duration = 0;
  uint32_t centimeters = 0;

  pinMode(15, OUTPUT); // trig
  pinMode(27, INPUT);  // echo


  // trigger
  digitalWrite(15, LOW);
  delayMicroseconds(2);
  digitalWrite(15, HIGH);
  delayMicroseconds(10);
  digitalWrite(15, LOW);

  // get echo
  duration = pulseIn(27, HIGH);

  // calculate
  centimeters = duration / 29 / 2;
  return centimeters;

}




void fixedDistance (void) {




  // test for 150mm range -- measure.RangeMilliMeter;

  uint32_t range = distanceMeasure();

  if ((range >= 15) && (range < 25)) {
    // move forward
    moveRobot (1, 1, 1); // speed 1 to 25, distance in steps (80 steps = 1 rev) , direction (1= forward, -1 = rev)
    // led (1, true);
    //  led (2, false);
    delay (10);



  } else if ((range > 5) && (range < 15)) {
    moveRobot (1, 1, -1); // speed 1 to 25, distance in steps (80 steps = 1 rev) , direction (1= forward, -1 = rev)
    //   led (2, true);
    //   led (1, false);
    delay (10);
  }// else {
  //   led (1, false);
  //  led (2, false);
  // }

}






/*#include <Adafruit_VL53L0X.h>


  Adafruit_VL53L0X lox =  Adafruit_VL53L0X();


  void setupLidar(void) {

  if (!lox.begin()) {
    Serial.println(F("Failed to boot VL53L0X"));
    while (1);
  }
  }


  //   Gets the measurement from the lidar sensor.
  //   @param none
  //   @return integer value of the measurement in millimeters (if out of range return -1.0)

  uint16_t getMeasurement(void) {
  VL53L0X_RangingMeasurementData_t measure;
  lox.rangingTest(&measure, false);

  if (measure.RangeStatus != 4) {
    Serial.print("Distance (mm): ");
    Serial.println(measure.RangeMilliMeter);
    return measure.RangeMilliMeter;
  } else {
    Serial.println("Out of range!");
    return -1.0;
  }

  }



  void fixedDistance (void) {

  VL53L0X_RangingMeasurementData_t measure;
  lox.rangingTest(&measure, false);

  if (measure.RangeStatus != 4) { // validity check

    //Serial.print("Distance (mm): "); Serial.println(measure.RangeMilliMeter);
    //return measure.RangeMilliMeter;


    // test for 150mm range -- measure.RangeMilliMeter;


    if (measure.RangeMilliMeter > 150) {
      // move forward
      moveRobot (10, 80, 1); // speed 1 to 25, distance in steps (80 steps = 1 rev) , direction (1= forward, -1 = rev)
      delay (300);
    }

  } else {
    Serial.println("Out of range!");
    //return -1.0;
  }
  }
*/
